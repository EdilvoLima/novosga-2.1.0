| Q                | A
| ---------------- | -----
| Bug report?      | yes/no
| Feature request? | yes/no
| MySQL version    | x.y.z
| PHP version      | x.y.z
| Platform/OS      | Debian 9.0
| Novo SGA version | x.y.z

<!--
- Please fill in this template according to your issue.
- Replace this comment by the description of your issue.
-->
